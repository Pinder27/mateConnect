-- AlterTable
ALTER TABLE "FlatMate" ADD COLUMN     "Type" TEXT NOT NULL DEFAULT 'any';
