-- AlterTable
ALTER TABLE "FlatMate" ADD COLUMN     "Gender" TEXT NOT NULL DEFAULT 'any';
