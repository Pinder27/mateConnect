import SignupForm from "../components/lib/signupForm/page";

export default async function Page(){
    return(
        <div>
            <SignupForm/>
        </div>
    )
}